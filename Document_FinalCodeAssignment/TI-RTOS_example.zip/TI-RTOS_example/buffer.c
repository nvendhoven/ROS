#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>

//#include <xdc/runtime/Assert.h>

#include <semaphore.h>
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>

#include "Board.h"

UART_Handle      handle;

pthread_mutex_t  uart_lock;
sem_t int_sem_compass, int_sem_airbag, int_sem_gps;

void check_errno(int error)
{
    if (error < 0)
    {
        perror("Error");
        while (1);
    }
}

void check(int error)
{
    if (error != 0)
    {
        printf("Error: %s\n", strerror(error));
        while (1);
    }
}

void write_to_uart(int cnt, char c, size_t size)
{
    char str[size];
    sprintf(str, "%d", cnt);

    int cnt_size = 0;
    int i = cnt;

    if(cnt == 0)
        cnt_size = 1;

    while(i != 0)
    {
        i /= 10;
        cnt_size += 1;
    }

    for(;cnt_size < size - 2; cnt_size++)
        str[cnt_size] = c;

    str[size - 3] = '\n';
    str[size - 2] = '\r';
    str[size - 1] = '\0';

    check_errno(pthread_mutex_lock(&uart_lock));
    UART_write(handle, str, size);
    check_errno(pthread_mutex_unlock(&uart_lock));
}


/* Task for compass */
void* compass_task(void* args)
{
    static int count = 0;

    while(1)
    {
        sem_wait(&int_sem_compass);

        write_to_uart(count, 'C', 32);

        count += 1;

        GPIO_write(Board_GPIO_11, 1);
        Task_sleep(1);
        GPIO_write(Board_GPIO_11, 0);
    }

    return NULL;
}

/* Task for airbag */
void* airbag_task(void* args)
{
    while(1)
    {
        sem_wait(&int_sem_airbag);

        Task_sleep(31);
        GPIO_write(Board_GPIO_10, 1);
        Task_sleep(1);
        GPIO_write(Board_GPIO_10, 0);
    }

    return NULL;
}

/* Task for gps */
void* gps_task(void* args)
{
    static int count = 0;

    while(1)
    {
        sem_wait(&int_sem_gps);

        write_to_uart(count, 'G', 64);

        count += 1;

        GPIO_write(Board_GPIO_09, 1);
        Task_sleep(1);
        GPIO_write(Board_GPIO_09, 0);
    }

    return NULL;
}

/* ISR for GPIO 06 */
void on_compass_event(uint_least8_t index)
{
    sem_post(&int_sem_compass);
}

/* ISR for GPIO 07 */
void on_airbag_event(uint_least8_t index)
{
    sem_post(&int_sem_airbag);
}

/* ISR for GPIO 08 */
void on_gps_event(uint_least8_t index)
{
    sem_post(&int_sem_gps);
}


void* main_thread(void* args)
{
    struct sched_param  spc1, spc2, spc3;
    pthread_attr_t      pta_prio_1, pta_prio_2, pta_prio_3;
    pthread_t           ptc_c, ptc_a, ptc_g;

    check_errno( sem_init(&int_sem_compass, 0, 0) );
    check_errno( sem_init(&int_sem_airbag, 0, 0) );
    check_errno( sem_init(&int_sem_gps, 0, 0) );

    check(pthread_attr_init(&pta_prio_1));
    check(pthread_attr_init(&pta_prio_2));
    check(pthread_attr_init(&pta_prio_3));

    check(pthread_attr_setstacksize(&pta_prio_1, 1024));
    check(pthread_attr_setstacksize(&pta_prio_2, 1024));
    check(pthread_attr_setstacksize(&pta_prio_3, 1024));

    check(pthread_attr_getschedparam(&pta_prio_1, &spc1));
    check(pthread_attr_getschedparam(&pta_prio_2, &spc2));
    check(pthread_attr_getschedparam(&pta_prio_3, &spc3));

    spc1.sched_priority = 1;
    spc2.sched_priority = 2;
    spc3.sched_priority = 3;

    check(pthread_attr_setschedparam(&pta_prio_1, &spc1));
    check(pthread_attr_setschedparam(&pta_prio_2, &spc2));
    check(pthread_attr_setschedparam(&pta_prio_3, &spc3));

    check(pthread_create(&ptc_c, &pta_prio_2, &compass_task, NULL));
    check(pthread_create(&ptc_a, &pta_prio_3, &airbag_task, NULL));
    check(pthread_create(&ptc_g, &pta_prio_1, &gps_task, NULL));

    check_errno(pthread_join(ptc_c, NULL));
    check_errno(pthread_join(ptc_a, NULL));
    check_errno(pthread_join(ptc_g, NULL));

    check_errno( sem_destroy(&int_sem_compass) );
    check_errno( sem_destroy(&int_sem_airbag) );
    check_errno( sem_destroy(&int_sem_gps) );

    return NULL;
}


int main(void)
{
    UART_Params params;
    UART_init();
    UART_Params_init(&params);

    params.baudRate  = 9600;
    params.writeDataMode = UART_DATA_BINARY;
    params.readDataMode = UART_DATA_BINARY;
    params.readReturnMode = UART_RETURN_FULL;
    params.readEcho = UART_ECHO_OFF;
    params.writeMode = UART_MODE_BLOCKING;

    handle = UART_open(0, &params);

    GPIO_init();

    /* install callback */
    GPIO_setCallback(Board_GPIO_06, on_compass_event);
    GPIO_setCallback(Board_GPIO_07, on_airbag_event);
    GPIO_setCallback(Board_GPIO_08, on_gps_event);

    /* Enable interrupts */
    GPIO_enableInt(Board_GPIO_06);
    GPIO_enableInt(Board_GPIO_07);
    GPIO_enableInt(Board_GPIO_08);

    check(pthread_mutex_init(&uart_lock, NULL));


    pthread_attr_t pta;
    check( pthread_attr_init(&pta) );
    check( pthread_attr_setdetachstate(&pta, PTHREAD_CREATE_DETACHED) );
    check( pthread_attr_setstacksize(&pta, 2048) );

    struct sched_param sp;
    check( pthread_attr_getschedparam(&pta, &sp) );
    sp.sched_priority = 15;
    check( pthread_attr_setschedparam(&pta, &sp) );

    pthread_t pt;
    check( pthread_create(&pt, &pta, main_thread, NULL) );

    printf("\n");
    BIOS_start();
    return EXIT_SUCCESS;
}
